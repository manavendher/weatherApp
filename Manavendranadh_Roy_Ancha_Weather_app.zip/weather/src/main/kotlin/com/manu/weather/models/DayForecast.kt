package com.manu.weather.models

data class DayForecast(val dayName: String, val tempHighCelsius: Double, val forecastBlurb: String)
